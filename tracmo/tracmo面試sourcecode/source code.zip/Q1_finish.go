package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"

	"github.com/apex/gateway"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/dynamodb/dynamodbattribute"
	"github.com/gin-gonic/gin"
)

type TracMoData struct {
	ID        string `json:"id"`
	Timestamp int    `json:"timestamp"` //unixtimestamp
	KeyA      string `json:"Key_A"`
	KeyB      string `json:"Key_B"`
	KeyC      string `json:"Key_C"`
	KeyD      string `json:"Key_D"`
	Userid    string `json:"user_id"`
}
type TracMoDataArray struct {
	TracMo []TracMoData `json:"tracmo"` //因為PDF寫小寫
}

func jsonHandler(c *gin.Context) {

	bytes, err := c.GetRawData()
	if err != nil {

		return
	}

	//讀取json並個別解析
	//要過濾必須值及存放於DB
	var TracMoDataA TracMoDataArray
	json.Unmarshal(bytes, &TracMoDataA)
	cred := credentials.NewStaticCredentials("AKIAINQVSGZ5H2FRWZEA", "KBAFktoJJcUAH6qWv+AvqJrCnRuTXu1dbV9/7zKH", ``)
	sess, err := session.NewSession(&aws.Config{
		Region:      aws.String("ap-southeast-1"),
		Credentials: cred, //credentials.NewSharedCredentials("C:\\Users\\Fox\\.aws\\credentials", "default"),
	})
	svc := dynamodb.New(sess)
	for i := 0; i < len(TracMoDataA.TracMo); i++ {
		if TracMoDataA.TracMo[i].ID == "" {
			continue
		}
		if TracMoDataA.TracMo[i].Timestamp == 0 {
			continue
		}
		if TracMoDataA.TracMo[i].KeyA == "" {
			TracMoDataA.TracMo[i].KeyA = " "
		}
		if TracMoDataA.TracMo[i].KeyB == "" {
			TracMoDataA.TracMo[i].KeyB = " "
		}
		if TracMoDataA.TracMo[i].KeyC == "" {
			TracMoDataA.TracMo[i].KeyC = " "
		}
		if TracMoDataA.TracMo[i].KeyD == "" {
			TracMoDataA.TracMo[i].KeyD = " "
		}
		if TracMoDataA.TracMo[i].Userid == "" {
			TracMoDataA.TracMo[i].Userid = " "
		}
		result, err := dynamodbattribute.MarshalMap(TracMoDataA.TracMo[i])

		if err != nil {
			fmt.Println("MarshalMap Error:")
			fmt.Println(err.Error())

		}

		// Create item in table Movies
		input := &dynamodb.PutItemInput{
			Item:      result,
			TableName: aws.String("T_Tracmo"),
		}

		_, err = svc.PutItem(input)

		if err != nil {
			fmt.Println("PutItem Error:")
			fmt.Println(err.Error())

		}
		c.String(http.StatusOK, "Successfully added\r\n")

	}

}
func routerEngine() *gin.Engine {
	// set server mode
	gin.SetMode(gin.DebugMode)

	r := gin.New()

	// Global middleware
	r.Use(gin.Logger())
	r.Use(gin.Recovery()) //不是很懂recovery用途須研究

	r.POST("/pAPI", jsonHandler)

	return r
}

func main() {
	gin.SetMode(gin.ReleaseMode)
	addr := ":" + os.Getenv("PORT")
	//addr = "localhost:4000"
	log.Fatal(gateway.ListenAndServe(addr, routerEngine()))

}
